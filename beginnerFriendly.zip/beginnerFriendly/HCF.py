def even_nums(x):
    print(x)
    if x == 2:
        return x
    else:
        return even_nums(x-2)
even_nums(10)