import tkinter as tk
import random

"""
border_effects = {
    "flat": tk.FLAT,
    "sunken": tk.SUNKEN,
    "raised": tk.RAISED,
    "groove": tk.GROOVE,
    "ridge": tk.RIDGE,
}

window = tk.Tk()

for relief_name, relief in border_effects.items():
    frame = tk.Frame(master=window, relief = relief, borderwidth=7)
    frame.pack(side=tk.LEFT)
    label = tk.Label(master=frame, text=relief_name)
    label.pack()
"""

window = tk.Tk()
window.columnconfigure(0, minsize= 150)

def roll():
    rand = random.randint(1,6)
    print(rand)
    lbl_num["text"] = f"{rand}"

button = tk.Button(text="Roll", command= roll)
button.grid(row=0, column=0, sticky='nsew')

lbl_num = tk.Label (text="0")
lbl_num.grid(row=1, column=0)


window.mainloop()
