import tkinter as tk
import string
from random import choice

word_file = open('word bank.txt', 'r')
answer = []
word = []
X = 0

word_list = word_file.readlines()
print(word_list)

# Declaring the Window and all the widgets to be used
window = tk.Tk()
fr_main = tk.Frame(window, width=300, height=400, relief=tk.GROOVE, borderwidth=5)
fr_main.pack()
fr_letter = tk.Frame(window, width=300, height=150, relief=tk.GROOVE, borderwidth=1)
for i in range(14):
    fr_letter.columnconfigure(i, minsize=20)
fr_letter.pack()

# Declaring the new game button
btn_new = tk.Button(fr_main, height=1, text="New Game")
# Adding the new game button to the grid
btn_new.pack(fill='x')
# Declaring the alphabet buttons
alpha_buttons = []
for i in string.ascii_uppercase:
    alpha_buttons.append(tk.Button(fr_letter, text=i))

# Placing the alphabet buttons on the frame
j = 0
for i in alpha_buttons:
    if j <= 13:
        i.grid(row=1, column=j, sticky='nsew')
    else:
        i.grid(row=2, column=j - 13, sticky='nsew')
    j += 1

# Declaring the solution Label
lbl_solution = tk.Label(fr_letter, height=2, relief=tk.GROOVE, borderwidth=1)
# Placing the solution label on the frame
lbl_solution.grid(row=0, column=0, columnspan=14, sticky='nsew')

# Declaring the canvas for drawing the hangman
canvas = tk.Canvas(fr_main, width=300, height=380)
# Placing the canvas on the frame
canvas.pack()

# drawing the gallows and initializing the parts of the man
shaft = [20, 20, 40, 350]
base = [20, 350, 200, 370]
overhang = [40, 20, 140, 40]

rope = [130, 40, 130, 100]
head = [100, 100, 160, 160]
body = [130, 160, 130, 280]
arms = [80, 200, 130, 170, 180, 200]
legs = [80, 310, 130, 280, 180, 310]

canvas.create_rectangle(shaft, fill='grey')
canvas.create_rectangle(base, fill='black')
canvas.create_rectangle(overhang, fill='grey')

"""
canvas.create_line(rope)
canvas.create_oval(head)
canvas.create_line(body)
canvas.create_line(arms)
canvas.create_line(legs)
"""


def initialize():
    global word, answer
    answer.clear()

    word = list(str.upper(choice(word_list)))
    if '\n' in word:
        word.remove('\n')
    print(word)

    for i in range(len(word)):
        answer.append("_")
    print(answer)

    spaces = ["'",'-',' ']
    for x in spaces:
        if find_letter(word, x):
            for i in find_letter(word, x):
                answer[i] = "-"
                if x == "'":
                    answer[i]="'"


    btn_new.config(command=initialize)

    lbl_solution.config(text=answer, font=25)

    for i in alpha_buttons:
        i.config(state=tk.NORMAL)
        i.bind('<ButtonRelease>', letter_pressed)


    for i in canvas.find_all():
        if i>3:
            canvas.delete(i)

    window.mainloop()


def find_letter(wrd, letter):
    return [idx for idx, value in enumerate(wrd) if value == letter]


def letter_pressed(event):
    global answer, word, X
    button = event.widget
    if button['state'] == tk.ACTIVE:
        button['state'] = tk.DISABLED
        letter = button["text"]
        print(letter)
        if letter not in answer:
            letter_index = find_letter(word, letter)
            if letter_index:
                for x in letter_index:
                    print(x)
                    answer[x] = letter
                    lbl_solution["text"] = answer
            else:
                X+=1
                incorrect(X)
        else:
            X+=1
            incorrect(X)


def incorrect(x):
    print("Incorrect")

    match x:
        case 1:
            canvas.create_line(rope)
        case 2:
            canvas.create_oval(head)
        case 3:
            canvas.create_line(body)
        case 4:
            canvas.create_line(arms)
        case 5:
            canvas.create_line(legs)


initialize()
